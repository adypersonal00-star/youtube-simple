# YouTube Simple — Privacy notice

This development build does not request Google sign-in, collect email addresses, or operate a backend. Profile fields are stored locally on the device only. Video playback uses YouTube's embedded player, which is provided by Google and may process data under Google's policies and YouTube Terms of Service. This app does not download videos. The app's API-backed features and account login are not yet implemented.

Google Privacy Policy: https://policies.google.com/privacy
YouTube Terms of Service: https://www.youtube.com/t/terms
