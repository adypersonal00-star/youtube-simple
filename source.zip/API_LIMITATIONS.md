# API and feature status

- Playback is provided by the official YouTube embedded player. The app does not download videos.
- YouTube Data API v3 does not expose the Community tab's posts or comments. The Community UI explicitly says unavailable and disables its composer/attachment/send controls; it does not invent content.
- Subscribing requires an authenticated Google account and authorized YouTube Data API access (OAuth scope `https://www.googleapis.com/auth/youtube`). The official `subscriptions.insert` request is not implemented; the button explains this and does not claim a subscription occurred.
- Liking a video requires user authorization and `videos.rate` with the YouTube Data API. OAuth and the API request are not implemented; the accessible Like control and left-swipe shortcut explain the requirement without claiming success.
- Channel details, genuine channel video/playlist lists, real search and tailored home recommendations require YouTube Data API integration. The visible sample items are clearly labeled examples, not personalized recommendations or verified Shorts.
- Google OAuth Android client registration requires a final package and SHA-1 from the signing certificate. No client was registered and no OAuth secret/token is in source.
